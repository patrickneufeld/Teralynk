// src/components/ui/Spinner.jsx
import React from "react";

const Spinner = () => {
  return <div>Loading...</div>;
};

export default Spinner;
