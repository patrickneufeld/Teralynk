// ================================================
// ✅ FILE: /frontend/src/components/Home.jsx
// Home Page for Teralynk — Public Route "/"
// ================================================

import React from "react";
import { Link } from "react-router-dom";
// Import the CSS file only if it exists (won't crash if missing in dev)
try { require("../styles/components/Home.css"); } catch {} // Safe CSS import

const Home = () => (
  <div className="home-container">
    <section className="hero" aria-labelledby="teralynk-hero-title">
      <h1 id="teralynk-hero-title">
        Welcome to <span className="brand">Teralynk</span>
      </h1>
      <p className="subtitle">
        Your unified file storage solution powered by AI.<br />
        Access, manage, and secure your files from anywhere, anytime.
      </p>
      <div className="cta-buttons">
        <Link to="/signup" className="cta-signup" aria-label="Sign up for Teralynk">
          Get Started
        </Link>
        <Link to="/about" className="cta-learn-more" aria-label="Learn more about Teralynk">
          Learn More
        </Link>
      </div>
    </section>

    <section className="key-features" aria-labelledby="features-title">
      <h2 id="features-title">Key Features</h2>
      <ul>
        <li><span aria-hidden="true">✅</span> Seamless integration with major cloud providers</li>
        <li><span aria-hidden="true">🔍</span> AI-powered file organization and search</li>
        <li><span aria-hidden="true">🔐</span> Secure sharing and collaboration tools</li>
        <li><span aria-hidden="true">📁</span> Customizable storage tiers for individuals and businesses</li>
      </ul>
    </section>

    <section className="testimonials" aria-labelledby="testimonials-title">
      <h2 id="testimonials-title">What Our Users Say</h2>
      <figure>
        <blockquote>
          🚀 "Teralynk has revolutionized the way we manage and organize files!"
        </blockquote>
        <figcaption>
          &mdash; <em>TechWorld</em>
        </figcaption>
      </figure>
      <figure>
        <blockquote>
          🔒 "A secure and AI-driven approach to cloud storage. Highly recommended!"
        </blockquote>
        <figcaption>
          &mdash; <em>CloudReview</em>
        </figcaption>
      </figure>
    </section>

    <footer className="home-footer" aria-label="Copyright">
      <p>
        &copy; {new Date().getFullYear()} Teralynk. All rights reserved.
      </p>
    </footer>
  </div>
);

export default Home;
