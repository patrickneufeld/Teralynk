// ================================================
// ✅ FILE: /frontend/src/utils/telemetry.js
// Centralized Telemetry Utility with Full Exports
// Version: 2.2.1
// ================================================

import { v4 as uuidv4 } from 'uuid';
import { logInfo, logError } from './logging';
import { MetricsCollector } from './metrics/MetricsCollector';

export const TELEMETRY_CONFIG = {
  enabled: import.meta.env.VITE_ENABLE_TELEMETRY !== 'false',
  endpoint: import.meta.env.VITE_TELEMETRY_ENDPOINT || 'http://localhost:5001/api/telemetry',
  batchSize: 10,
  flushInterval: 5000,
  maxQueueSize: 100,
  retryAttempts: 3,
  traceIdPrefix: 'trace_',
};

let currentTraceId = null;
let currentSessionId = null;
let eventQueue = [];
let flushTimeout = null;

let metrics;
try {
  metrics = new MetricsCollector('telemetry');
} catch (err) {
  logError('Failed to initialize metrics collector', err);
}

export function generateTraceId() {
  currentTraceId = `${TELEMETRY_CONFIG.traceIdPrefix}${uuidv4()}`;
  return currentTraceId;
}

export function getTraceId() {
  return currentTraceId || generateTraceId();
}

export function getSessionId() {
  if (!currentSessionId) {
    currentSessionId = uuidv4();
  }
  return currentSessionId;
}

export function emitTelemetry(event, payload = {}) {
  if (!TELEMETRY_CONFIG.enabled) return;
  const traceId = getTraceId();
  const sessionId = getSessionId();
  const timestamp = new Date().toISOString();

  const eventData = {
    traceId,
    sessionId,
    event,
    timestamp,
    ...payload,
  };

  eventQueue.push(eventData);
  if (metrics) metrics.increment(`telemetry.event.${event}`);

  if (eventQueue.length >= TELEMETRY_CONFIG.batchSize) {
    flushTelemetryQueue();
  } else if (!flushTimeout) {
    flushTimeout = setTimeout(flushTelemetryQueue, TELEMETRY_CONFIG.flushInterval);
  }
}

export async function flushTelemetryQueue() {
  if (!eventQueue.length) return;
  const queueToSend = [...eventQueue];
  eventQueue = [];
  clearTimeout(flushTimeout);
  flushTimeout = null;

  try {
    const res = await fetch(TELEMETRY_CONFIG.endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(queueToSend),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    logInfo(`📤 Sent ${queueToSend.length} telemetry events`);
  } catch (err) {
    logError('Telemetry send failed', err);
    eventQueue.unshift(...queueToSend);
  }
}

export { emitTelemetry as sendTelemetryEvent }
