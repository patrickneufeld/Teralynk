// ================================================
// ✅ FILE: /frontend/src/utils/security/secureStorage.js
// Secure Encrypted Storage with Device Fingerprinting
// Version: 2.2.3 — Explicit SecureStorage export
// ================================================

import { v4 as uuidv4 } from 'uuid';
import { logInfo, logError } from '@/utils/logging';
import { encrypt, decrypt } from '@/utils/encryption';
import { getDeviceFingerprint } from '@/utils/authUtils';

const STORAGE_NAMESPACE = 'teralynk_secure_';
const TTL_DEFAULT = 1000 * 60 * 60 * 24 * 7; // 7 days

class SecureStorage {
  constructor() {
    this.fingerprint = null;
  }

  async init() {
    try {
      this.fingerprint = await getDeviceFingerprint();
      logInfo('SecureStorage initialized', { fingerprint: this.fingerprint });
    } catch (err) {
      logError('Failed to initialize SecureStorage', err);
    }
  }

  _getKey(key) {
    return `${STORAGE_NAMESPACE}${key}`;
  }

  async setItem(key, value, ttl = TTL_DEFAULT) {
    try {
      const encrypted = await encrypt(JSON.stringify(value));
      const expires = Date.now() + ttl;
      const payload = {
        value: encrypted,
        expires,
        fingerprint: this.fingerprint,
      };
      localStorage.setItem(this._getKey(key), JSON.stringify(payload));
    } catch (err) {
      logError('SecureStorage.setItem failed', { key, error: err.message });
    }
  }

  async getItem(key) {
    try {
      const raw = localStorage.getItem(this._getKey(key));
      if (!raw) return null;

      const parsed = JSON.parse(raw);
      if (Date.now() > parsed.expires) {
        this.removeItem(key);
        return null;
      }

      const decrypted = await decrypt(parsed.value);
      return JSON.parse(decrypted);
    } catch (err) {
      logError('SecureStorage.getItem failed', { key, error: err.message });
      return null;
    }
  }

  removeItem(key) {
    try {
      localStorage.removeItem(this._getKey(key));
    } catch (err) {
      logError('SecureStorage.removeItem failed', { key, error: err.message });
    }
  }

  clearAll() {
    try {
      Object.keys(localStorage).forEach((key) => {
        if (key.startsWith(STORAGE_NAMESPACE)) {
          localStorage.removeItem(key);
        }
      });
    } catch (err) {
      logError('SecureStorage.clearAll failed', err);
    }
  }

  async exportAll() {
    const result = {};
    try {
      for (const key of Object.keys(localStorage)) {
        if (key.startsWith(STORAGE_NAMESPACE)) {
          const shortKey = key.replace(STORAGE_NAMESPACE, '');
          result[shortKey] = await this.getItem(shortKey);
        }
      }
    } catch (err) {
      logError('SecureStorage.exportAll failed', err);
    }
    return result;
  }
}

const secureStorage = new SecureStorage();
await secureStorage.init();

// ✅ EXPLICIT EXPORTS
export { SecureStorage, secureStorage };
export default secureStorage;
