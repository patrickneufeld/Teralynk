// ================================================
// ✅ FILE: /frontend/src/utils/security/eventEmitter.js
// Hardened Singleton EventEmitter with Security Events
// Version: 2.2.5 — Duplicate Export Fix Complete
// ================================================

import { logInfo, logError } from '@/utils/logging';
import { v4 as uuidv4 } from 'uuid';
import { emitTelemetry } from '@/utils/telemetry';

// 🛡️ List of supported security event types
const SECURITY_EVENTS = Object.freeze({
  LOGIN_SUCCESS: 'security.login.success',
  LOGIN_FAILURE: 'security.login.failure',
  LOGOUT: 'security.logout',
  TOKEN_REFRESHED: 'security.token.refreshed',
  TOKEN_EXPIRED: 'security.token.expired',
  DEVICE_FINGERPRINT_CHANGED: 'security.device.fingerprint.changed',
  STORAGE_INITIALIZED: 'security.storage.initialized',
  SESSION_VALIDATED: 'security.session.validated',
  UNAUTHORIZED_ACCESS: 'security.unauthorized.access',
  MFA_REQUIRED: 'security.mfa.required',
  MFA_VERIFIED: 'security.mfa.verified',
  INACTIVITY_LOGOUT: 'security.inactivity.logout',
  INVALID_TOKEN: 'security.invalid.token',
  RATE_LIMIT: 'security.rate.limit',
  SECURITY_ERROR: 'security.error',
  AUTH_FAILURE: 'security.auth.failure',
});

// 🔁 Singleton class to manage emit/on/off/removeAll
class SecurityEventEmitter {
  constructor() {
    if (!SecurityEventEmitter.instance) {
      this.listeners = {};
      SecurityEventEmitter.instance = this;
    }
    return SecurityEventEmitter.instance;
  }

  on(event, callback) {
    if (!this.listeners[event]) {
      this.listeners[event] = [];
    }
    this.listeners[event].push(callback);
    logInfo(`🔐 Registered listener for ${event}`);
  }

  off(event, callback) {
    if (!this.listeners[event]) return;
    this.listeners[event] = this.listeners[event].filter((cb) => cb !== callback);
    logInfo(`❌ Removed listener for ${event}`);
  }

  emit(event, payload = {}) {
    const traceId = uuidv4();
    const timestamp = Date.now();
    logInfo(`🔔 Emitting security event: ${event}`, { traceId, payload });
    emitTelemetry(event, { traceId, timestamp, ...payload });

    if (this.listeners[event]) {
      for (const cb of this.listeners[event]) {
        try {
          cb({ traceId, timestamp, ...payload });
        } catch (err) {
          logError(`SecurityEventEmitter callback error: ${err.message}`, { event });
        }
      }
    }
  }

  removeAll() {
    this.listeners = {};
    logInfo('🧹 All security event listeners removed');
  }
}

// ✅ Singleton instance
const instance = new SecurityEventEmitter();
Object.freeze(instance);

// ✅ Final exports (NO DUPLICATES)
export { instance as SecurityEventEmitter };
export { SECURITY_EVENTS };
export const emitSecurityEvent = (event, payload = {}) =>
  instance.emit(event, payload);
