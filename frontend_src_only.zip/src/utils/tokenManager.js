// ================================================
// ✅ FILE: /frontend/src/utils/tokenManager.js
// Secure Token Management with Enhanced Security
// Version: 3.1.4 — Fixed removeToken export & structure
// ================================================

import { v4 as uuidv4 } from 'uuid';
import { memoize } from 'lodash';
import { openDB } from 'idb';
import { encrypt, decrypt, hashSHA256 } from './encryption';
import { logInfo, logError, logWarn } from './logging';
import { emitTelemetry } from './telemetry';
import { SecurityEventEmitter } from './security/eventEmitter';
import { RateLimiter } from './RateLimiter';

const DB_NAME = 'tokenStorage';
const DB_VERSION = 1;
const STORE_NAME = 'tokens';
const SESSION_KEY_STORE = 'sessionKeys';
const TTL = 1000 * 60 * 60 * 2;

const TOKEN_KEYS = {
  ACCESS: 'accessToken',
  REFRESH: 'refreshToken',
  EXPIRY: 'tokenExpiry',
  SESSION: 'sessionKey',
  DEVICE: 'deviceId',
};

let dbPromise = openDB(DB_NAME, DB_VERSION, {
  upgrade(db) {
    if (!db.objectStoreNames.contains(STORE_NAME)) {
      db.createObjectStore(STORE_NAME);
    }
    if (!db.objectStoreNames.contains(SESSION_KEY_STORE)) {
      db.createObjectStore(SESSION_KEY_STORE);
    }
  },
});

const getFromDB = async (key) => {
  try {
    const db = await dbPromise;
    return await db.get(STORE_NAME, key);
  } catch (e) {
    logError('Failed to get from DB', { key, error: e.message });
    return null;
  }
};

const setToDB = async (key, value) => {
  try {
    const db = await dbPromise;
    await db.put(STORE_NAME, value, key);
  } catch (e) {
    logError('Failed to write to DB', { key, error: e.message });
  }
};

const deleteFromDB = async (key) => {
  try {
    const db = await dbPromise;
    await db.delete(STORE_NAME, key);
  } catch (e) {
    logError('Failed to delete from DB', { key, error: e.message });
  }
};

const clearDB = async () => {
  try {
    const db = await dbPromise;
    await db.clear(STORE_NAME);
  } catch (e) {
    logError('Failed to clear DB', e);
  }
};

const getSessionKey = memoize(() => {
  try {
    return uuidv4();
  } catch (e) {
    logError('Failed to generate session key', e);
    return null;
  }
});

const getDeviceId = async () => {
  let deviceId = await getFromDB(TOKEN_KEYS.DEVICE);
  if (!deviceId) {
    deviceId = uuidv4();
    await setToDB(TOKEN_KEYS.DEVICE, deviceId);
  }
  return deviceId;
};

const encryptToken = async (token) => {
  try {
    return await encrypt(token);
  } catch (e) {
    logError('Token encryption failed', e);
    return null;
  }
};

async function setToken(key, value, ttl = TTL) {
  try {
    const encrypted = await encryptToken(value);
    const payload = {
      value: encrypted,
      timestamp: Date.now(),
      ttl,
    };
    const db = await dbPromise;
    await db.put(STORE_NAME, payload, key);
    logInfo('Token set', { key });
  } catch (err) {
    logError('Failed to set token', { key, error: err.message });
  }
}

async function getToken(key) {
  try {
    const db = await dbPromise;
    const entry = await db.get(STORE_NAME, key);
    if (!entry) return null;
    if (Date.now() > entry.timestamp + entry.ttl) {
      await db.delete(STORE_NAME, key);
      return null;
    }
    return await decrypt(entry.value);
  } catch (err) {
    logError('Failed to get token', { key, error: err.message });
    return null;
  }
}

async function validateToken(key) {
  const token = await getToken(key);
  return !!token;
}

async function clearTokens() {
  try {
    const db = await dbPromise;
    await db.clear(STORE_NAME);
    await db.clear(SESSION_KEY_STORE);
    logInfo('All tokens cleared');
  } catch (err) {
    logError('Failed to clear tokens', err);
  }
}

async function removeToken(key) {
  try {
    await deleteFromDB(key);
    logInfo('Token removed', { key });
  } catch (err) {
    logError('Failed to remove token', { key, error: err.message });
  }
}

async function listTokens() {
  try {
    const db = await dbPromise;
    return await db.getAllKeys(STORE_NAME);
  } catch (err) {
    logError('Failed to list tokens', err);
    return [];
  }
}

async function setSessionKey(userId, sessionKey) {
  try {
    const hashed = await hashSHA256(sessionKey);
    const db = await dbPromise;
    await db.put(SESSION_KEY_STORE, hashed, userId);
  } catch (err) {
    logError('Failed to set session key', { userId, error: err.message });
  }
}

async function getSessionKeyStored(userId) {
  try {
    const db = await dbPromise;
    return await db.get(SESSION_KEY_STORE, userId);
  } catch (err) {
    logError('Failed to get session key', { userId, error: err.message });
    return null;
  }
}

async function removeSessionKey(userId) {
  try {
    const db = await dbPromise;
    await db.delete(SESSION_KEY_STORE, userId);
  } catch (err) {
    logError('Failed to remove session key', { userId, error: err.message });
  }
}

function createSecureTokenId(prefix = 'token') {
  return `${prefix}_${uuidv4()}`;
}

async function exportTokenBundle() {
  try {
    const db = await dbPromise;
    const tokens = await db.getAll(STORE_NAME);
    const sessionKeys = await db.getAll(SESSION_KEY_STORE);
    return {
      tokens,
      sessionKeys,
      exportedAt: new Date().toISOString(),
    };
  } catch (err) {
    logError('Failed to export token bundle', { error: err.message });
    return null;
  }
}

async function initTokenManager(userId) {
  try {
    const deviceId = await getDeviceId();
    const sessionKey = getSessionKey(userId);
    logInfo('Token Manager initialized', { userId, deviceId });
    emitTelemetry('token.initialized', {
      userId,
      deviceId,
      sessionKey,
    });
    return { deviceId, sessionKey };
  } catch (err) {
    logError('Failed to initialize Token Manager', { error: err.message });
    return null;
  }
}

async function emitTokenEvent(eventType, payload = {}) {
  try {
    const traceId = createSecureTokenId('trace');
    SecurityEventEmitter.emit(eventType, {
      traceId,
      timestamp: Date.now(),
      ...payload,
    });
    emitTelemetry('token.event', { eventType, ...payload });
  } catch (err) {
    logError('Failed to emit token event', { eventType, error: err.message });
  }
}

// ✅ FIXED EXPORTS
export {
  getToken,
  setToken,
  validateToken,
  clearTokens,
  removeToken, // ✅ Fixed: now exported
  listTokens,
  setSessionKey,
  getSessionKeyStored as getSessionKey,
  removeSessionKey,
  createSecureTokenId,
  exportTokenBundle,
  initTokenManager,
  emitTokenEvent
};
