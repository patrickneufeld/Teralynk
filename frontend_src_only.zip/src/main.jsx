// ================================================
// ✅ FILE: /frontend/src/main.jsx
// Hardened React 18 Entry Point with RouterProvider
// ================================================

import React from "react";
import { createRoot } from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import App from "./App";
import "./styles/global/global.css";

// Fallback UI for loading state
const LoadingFallback = () => (
  <div style={{ padding: "2rem", textAlign: "center" }}>Loading...</div>
);

// Global render-time error component
const ErrorComponent = () => (
  <div style={{ padding: "2rem", textAlign: "center" }}>
    <h2>Something went wrong</h2>
    <button onClick={() => window.location.reload()}>Refresh Page</button>
  </div>
);

// Full router config with App wrapped
const router = createBrowserRouter(
  [
    {
      path: "*",
      element: <App />,
      errorElement: <ErrorComponent />,
    },
  ],
  {
    future: {
      v7_startTransition: true,
      v7_relativeSplatPath: true,
      v7_fetcherPersist: true,
      v7_normalizeFormMethod: true,
      v7_partialHydration: true,
      v7_skipActionErrorRevalidation: true,
    },
  }
);

const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("❌ Root element not found in index.html");

const root = createRoot(rootElement);

try {
  root.render(
    <React.StrictMode>
      <RouterProvider router={router} fallbackElement={<LoadingFallback />} />
    </React.StrictMode>
  );
} catch (error) {
  console.error("🚨 Fatal render error:", error);
  root.render(
    <div style={{ padding: "2rem", textAlign: "center", color: "red" }}>
      <h2>Fatal Error</h2>
      <pre>{error.toString()}</pre>
    </div>
  );
}
