// ================================================
// ✅ FILE: /frontend/src/index.js
// React entry point with all global context providers
// ================================================

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App'; // ✅ Correct relative path
import { BrowserRouter as Router } from 'react-router-dom';

// 🌐 Global Context Providers
import { AuthProvider } from './contexts/AuthContext';
import { SecretsProvider } from './contexts/SecretsContext';
import { ThemeProvider } from './contexts/ThemeContext';
import ModalProvider from './contexts/ModalContext';
import NotificationProvider from './contexts/NotificationContext';

// 💅 Global Styles
import './styles/global.css'; // ✅ Ensure CSS exists

// 🔌 Mount point
const root = ReactDOM.createRoot(document.getElementById('root'));

// 🚀 Render application with full context hierarchy
root.render(
  <React.StrictMode>
    <Router>
      <AuthProvider>
        <SecretsProvider>
          <ThemeProvider>
            <NotificationProvider>
              <ModalProvider>
                <App />
              </ModalProvider>
            </NotificationProvider>
          </ThemeProvider>
        </SecretsProvider>
      </AuthProvider>
    </Router>
  </React.StrictMode>
);
