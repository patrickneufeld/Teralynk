// ================================================
// ✅ FILE: /frontend/src/contexts/AuthContext.jsx
// Hardened React Auth Context with Security Events (v2.3.7)
// ================================================

import React, {
  createContext,
  useContext,
  useReducer,
  useEffect,
  useRef,
  useCallback,
  useMemo,
} from 'react';
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';

import api from '@/api/apiClient';
import { authReducer, initialState, AUTH_ACTIONS } from '@/reducers/authReducer';
import { SECURITY_POLICIES } from '@/constants/auth';
import { logInfo, logError, logWarn, logDebug } from '@/utils/logging';
import { SECURITY_EVENTS, emitSecurityEvent } from '@/utils/security/eventEmitter';
import secureStorage from '@/utils/security/secureStorage';
import * as tokenManager from '@/utils/tokenManager';
import { getRawDeviceId } from '@/utils/security/deviceUtils';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);
  const navigate = useNavigate();
  const initialized = useRef(false);

  const validateSession = useCallback(async () => {
    try {
      const token = await tokenManager.getToken();
      if (!token) throw new Error('Missing token');

      const session = await api.get('/auth/session');
      dispatch({ type: AUTH_ACTIONS.LOGIN_SUCCESS, payload: session.data });
      logInfo('✅ Session validated', session.data);
    } catch (err) {
      logWarn('Session validation failed', { error: err.message });
      dispatch({ type: AUTH_ACTIONS.LOGOUT });
    }
  }, []);

  const login = useCallback(async (credentials) => {
    try {
      const response = await api.post('/auth/login', credentials);
      const { token, user } = response.data;

      await tokenManager.setToken(token);
      dispatch({ type: AUTH_ACTIONS.LOGIN_SUCCESS, payload: user });
      emitSecurityEvent(SECURITY_EVENTS.LOGIN_SUCCESS, { user });
      navigate('/dashboard');
    } catch (err) {
      emitSecurityEvent(SECURITY_EVENTS.LOGIN_FAILURE, { reason: err.message });
      logError('❌ Login failed', err);
      throw err;
    }
  }, [navigate]);

  const logout = useCallback(async () => {
    try {
      await tokenManager.clearTokens();
      dispatch({ type: AUTH_ACTIONS.LOGOUT });
      emitSecurityEvent(SECURITY_EVENTS.LOGOUT);
      navigate('/login');
    } catch (err) {
      logError('❌ Logout failed', err);
    }
  }, [navigate]);

  useEffect(() => {
    if (!initialized.current) {
      validateSession();
      initialized.current = true;
    }
  }, [validateSession]);

  const contextValue = useMemo(() => ({
    ...state,
    login,
    logout,
    dispatch,
    securityPolicies: SECURITY_POLICIES,
    rawDeviceId: getRawDeviceId(),
  }), [state, login, logout, dispatch]);

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

AuthProvider.propTypes = {
  children: PropTypes.node.isRequired,
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('❌ useAuth() must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;
