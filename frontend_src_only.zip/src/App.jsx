// ================================================
// ✅ FILE: /frontend/src/App.jsx
// Enterprise-Grade Application Root for Teralynk
// ================================================

import React, { Suspense, useEffect, useRef } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';

import { useAuth } from '@/contexts/AuthContext';
import { logInfo, logError } from '@/utils/logging';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorBoundary from '@/utils/logging/ErrorBoundary';
import RootLayout from '@/layouts/RootLayout';
import routeConfig from '@/routes/config';

const App = () => {
  const location = useLocation();
  const firstRenderRef = useRef(true);
  const auth = useAuth();

  useEffect(() => {
    if (!auth) {
      logError('❌ useAuth() returned undefined. AuthProvider may not be mounted.');
    }
  }, [auth]);

  useEffect(() => {
    if (firstRenderRef.current) {
      logInfo('🚀 App initialized');
      firstRenderRef.current = false;
    } else {
      logInfo('📍 Route changed', { pathname: location.pathname });
    }
  }, [location.pathname]);

  if (!auth) {
    return (
      <div style={{ padding: '2rem', textAlign: 'center', color: 'red' }}>
        <h2>Authentication Error</h2>
        <p>AuthContext not available. Please restart the app.</p>
      </div>
    );
  }

  const { isAuthenticated } = auth;

  const renderRoutes = () =>
    Object.entries(routeConfig).flatMap(([category, routes]) =>
      routes.map(({ path, element, permissions, requiresAuth }, index) => {
        const key = `${category}-${index}`;
        const wrappedElement = requiresAuth ? (
          isAuthenticated ? (
            element
          ) : (
            <Navigate to="/login" replace />
          )
        ) : (
          element
        );

        return <Route key={key} path={path} element={wrappedElement} />;
      })
    );

  return (
    <ErrorBoundary>
      <RootLayout>
        <Suspense fallback={<LoadingSpinner />}>
          <Routes>{renderRoutes()}</Routes>
        </Suspense>
      </RootLayout>
    </ErrorBoundary>
  );
};

export default App;
