// ================================================
// ✅ FILE: /frontend/src/index.js
// Root React Entry Point — Mounts App with Providers
// ================================================

import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';

// 🧠 App entry and context providers
import App from './App';
import {
  AuthProvider,
  SecretsProvider,
  ThemeProvider,
  NotificationProvider,
  ModalProvider,
} from './contexts';

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <AuthProvider>
      <SecretsProvider>
        <ThemeProvider>
          <NotificationProvider>
            <ModalProvider>
              <BrowserRouter>
                <App />
              </BrowserRouter>
            </ModalProvider>
          </NotificationProvider>
        </ThemeProvider>
      </SecretsProvider>
    </AuthProvider>
  </React.StrictMode>
);
