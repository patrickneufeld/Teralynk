// Dashboard.jsx - Part 1
import React, { useEffect, useState, useCallback, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useSecrets } from "@/hooks/useSecrets";
import { Card, CardContent } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Alert } from "@/components/ui/Alert";
import Spinner from "@/components/ui/Spinner";
import SecurityConsole from "@/components/SecurityConsole";
import ErrorBoundary from "@/components/ErrorBoundary";
import Skeleton from "@/components/ui/Skeleton";
import { logError, logInfo } from "@/utils/logging/logging";
import { securityEvents, SECURITY_EVENTS } from "@/utils/security/eventEmitter";
import tokenManager from "@/utils/tokenManager";
import axios from "axios";
import { formatDistanceToNow } from "date-fns";
import AIOverviewPanel from "@/components/AIOverviewPanel";
import InsightSummaryWidget from "@/components/InsightSummaryWidget";
import AIForecastTrendWidget from "@/components/AIForecastTrendWidget";

// Create axios instance with CORS headers
const api = axios.create({
  baseURL: import.meta.env.VITE_BACKEND_URL || "http://localhost:5001",
  withCredentials: true,
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
  }
});

// Add response interceptor for error handling
api.interceptors.response.use(
  response => response,
  error => {
    if (error.response?.status === 401) {
      tokenManager.removeAllTokens();
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

const initialSecurityStatus = {
  mfaEnabled: false,
  passwordStrength: "unknown",
  securityScore: 0,
  activeThreats: 0,
  riskLevel: "low",
};

const initialMetrics = {
  performance: {},
  storage: {},
  fileInsights: {},
  optimizations: [],
};

const initialUserContext = {
  user: null,
  usage: {},
  recentFiles: [],
};

function Dashboard() {
  const navigate = useNavigate();
  const { user = {}, loggedIn } = useAuth();
  const { getSecrets } = useSecrets();
  
  // State declarations
  const [wsConnection, setWsConnection] = useState(null);
  const [wsMessage, setWsMessage] = useState(null);
  const [data, setData] = useState(initialUserContext);
  const [metrics, setMetrics] = useState(initialMetrics);
  const [activities, setActivities] = useState([]);
  const [aiInsights, setAiInsights] = useState([]);
  const [aiRecommendations, setAiRecommendations] = useState([]);
  const [securityStatus, setSecurityStatus] = useState(initialSecurityStatus);
  const [aiLearningFeedback, setAiLearningFeedback] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);

  const authHeaders = useMemo(() => ({
    Authorization: `Bearer ${tokenManager.getToken()}`,
    "X-Client-Version": import.meta.env.VITE_APP_VERSION,
    "X-Request-ID": crypto.randomUUID(),
    "X-User-ID": user?.id || '',
    "X-Session-ID": sessionStorage.getItem("sessionId")
  }), [user?.id]);

  // Setup API instance with auth headers
  useEffect(() => {
    api.defaults.headers.common = {
      ...api.defaults.headers.common,
      ...authHeaders
    };
  }, [authHeaders]);

  // WebSocket setup with error handling
  useEffect(() => {
    if (!user?.id) return;

    const setupWebSocket = async () => {
      try {
        const token = await tokenManager.getToken();
        if (!token) {
          throw new Error('No authentication token available');
        }

        const ws = new WebSocket(
          `${import.meta.env.VITE_WS_URL || 'ws://localhost:5001'}/ws/user-updates`
        );

        ws.onopen = () => {
          ws.send(JSON.stringify({ type: 'auth', token }));
          logInfo('WebSocket connection established');
        };

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            setWsMessage(data);
          } catch (err) {
            logError('Failed to parse WebSocket message', err);
          }
        };

        ws.onerror = (error) => {
          logError('WebSocket error:', error);
        };

        ws.onclose = () => {
          logInfo('WebSocket connection closed');
        };

        setWsConnection(ws);

        return () => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.close();
          }
        };
      } catch (err) {
        logError('WebSocket setup failed:', err);
        // Retry connection after delay
        setTimeout(setupWebSocket, 5000);
      }
    };

    setupWebSocket();
  }, [user?.id]);
// Dashboard.jsx - Part 2 (continuation)

  const fetchDashboardData = useCallback(async () => {
    if (!loggedIn || !user?.id) {
      navigate('/login');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const perfTrackingId = await aiPerformanceService.startTracking("dashboard_load");

      // Wrap each API call in a try-catch block
      const safeApiCall = async (promise, fallback) => {
        try {
          const response = await promise;
          return response?.data || fallback;
        } catch (err) {
          logError(`API call failed: ${err.message}`);
          return fallback;
        }
      };

      const [
        perfStats,
        perfLogs,
        usageData,
        costData,
        recommendationsData,
        insightsData,
        securityData,
        filenameSuggestions,
        userData,
        metricsData,
        activitiesData
      ] = await Promise.all([
        safeApiCall(aiPerformanceService.getStats(user.id), {}),
        safeApiCall(aiPerformanceService.getLogs(user.id), []),
        safeApiCall(api.get('/api/storage/usage'), { usage: 0 }),
        safeApiCall(api.get('/api/storage/cost-analysis'), { cost: 0 }),
        safeApiCall(api.get('/api/storage/recommendations'), []),
        safeApiCall(api.get('/api/insights'), []),
        safeApiCall(api.get(`/api/security/status?userId=${user.id}`), initialSecurityStatus),
        safeApiCall(aiFileNamingService.getSuggestions(user.id), {}),
        safeApiCall(api.get('/api/user-data'), {}),
        safeApiCall(dashboardService.getMetrics(user.id), {}),
        safeApiCall(dashboardService.getActivities(user.id), [])
      ]);

      // Update state with fallback values
      setData({
        user: userData,
        recentFiles: userData.recentFiles || [],
        usage: userData.usage || {}
      });

      setMetrics({
        performance: { 
          stats: perfStats || {}, 
          logs: perfLogs || [] 
        },
        storage: {
          usage: usageData,
          cost: costData,
          recommendations: recommendationsData
        },
        fileInsights: insightsData || [],
      });

      setSecurityStatus(securityData);
      setAiInsights(insightsData || []);
      setActivities((activitiesData || []).map((a) => ({
        ...a,
        filenameSuggestion: filenameSuggestions[a.id] || null,
        aiInsight: insightsData?.activityInsights?.[a.id] || null
      })));
      setAiRecommendations(recommendationsData || []);

      await aiPerformanceService.stopTracking(perfTrackingId, {
        success: true,
        metrics: {
          insightsGenerated: insightsData?.length || 0,
          dataPoints: Object.keys(metricsData || {}).length
        }
      });

      setRetryCount(0);

    } catch (err) {
      logError("Dashboard fetch failed", err);
      setRetryCount(prev => prev + 1);

      if (retryCount < 3) {
        const delay = Math.min(1000 * Math.pow(2, retryCount), 10000);
        setTimeout(() => fetchDashboardData(), delay);
      } else {
        setError("Failed to load dashboard data. Please try again later.");
      }
    } finally {
      setLoading(false);
    }
  }, [user?.id, loggedIn, navigate, retryCount]);

  // Effect for handling WebSocket messages
  useEffect(() => {
    if (!wsMessage) return;

    try {
      if (typeof wsMessage === 'string') {
        wsMessage = JSON.parse(wsMessage);
      }

      switch (wsMessage.type) {
        case 'metrics':
          setMetrics(prev => ({
            ...prev,
            performance: {
              ...prev.performance,
              live: wsMessage.data
            }
          }));
          break;

        case 'activity':
          setActivities(prev => [
            {
              ...wsMessage.data,
              aiInsight: wsMessage.insight,
              filenameSuggestion: wsMessage.filenameSuggestion
            },
            ...prev.slice(0, 49)
          ]);
          break;

        case 'security':
          setSecurityStatus(prev => ({
            ...prev,
            ...wsMessage.data
          }));
          break;

        case 'ai_feedback':
          setAiLearningFeedback(prev => [
            ...prev,
            wsMessage.message
          ].slice(-10));
          break;

        default:
          logError(`Unknown WebSocket message type: ${wsMessage.type}`);
      }
    } catch (err) {
      logError("WebSocket message processing error", err);
    }
  }, [wsMessage]);

  // Security events handler
  useEffect(() => {
    if (!user?.id) return;

    const handleSecurityEvent = async (newStatus) => {
      try {
        setSecurityStatus(prev => ({
          ...prev,
          ...newStatus
        }));

        const aiSecurityInsight = await aiSecurityManager.analyzeSecurityChange(newStatus);
        
        if (aiSecurityInsight) {
          setAiInsights(prev => [...prev, aiSecurityInsight]);
          setAiLearningFeedback(prev => [
            ...prev,
            `Security event analyzed: ${aiSecurityInsight.message || "Unknown"}`
          ].slice(-10));
        }
      } catch (err) {
        logError("Security event processing failed", err);
      }
    };

    const unsubscribe = securityEvents.on(
      SECURITY_EVENTS.SECURITY_STATUS_CHANGED,
      handleSecurityEvent
    );

    const monitor = aiSecurityManager.startMonitoring(user.id);

    return () => {
      unsubscribe?.();
      monitor?.stop?.();
      wsConnection?.close();
    };
  }, [user?.id, wsConnection]);

  // Initial data fetch
  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <Spinner size="lg" />
        <p className="mt-4 text-gray-600 dark:text-gray-300">
          Loading your personalized dashboard...
        </p>
        <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
          AI is analyzing your latest activities
        </p>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="error" className="max-w-3xl mx-auto mt-12">
        <h2 className="text-xl font-semibold mb-2">Dashboard Error</h2>
        <p>{error}</p>
        <div className="mt-4 space-y-2">
          <Button onClick={fetchDashboardData}>Retry Load</Button>
        </div>
      </Alert>
    );
  }

  return (
    <ErrorBoundary>
      <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8" data-testid="dashboard-content">
        {/* Your existing JSX remains the same */}
      </div>
    </ErrorBoundary>
  );
}

export default Dashboard;
