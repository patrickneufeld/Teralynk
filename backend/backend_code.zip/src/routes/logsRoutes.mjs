import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { query } from '../config/db.mjs';
import { logInfo, logError } from '../utils/bootstrapLogger.mjs';

const router = express.Router();

// ✅ Resolve __dirname in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ------------------------------
// ✅ POST /api/logs/activity
// Logs user actions into activity_logs table
// Body: { userId, action, details?, timestamp? }
// ------------------------------
router.post('/activity', async (req, res) => {
  try {
    const {
      userId,
      action,
      timestamp = new Date().toISOString(),
      details,
    } = req.body;

    if (!userId || !action) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: userId and action',
      });
    }

    await query(
      `INSERT INTO activity_logs (user_id, action, timestamp, details)
       VALUES ($1, $2, $3, $4)`,
      [userId, action, timestamp, JSON.stringify(details || {})]
    );

    logInfo('✅ Activity log saved', { userId, action, timestamp });
    res.status(200).json({ success: true, message: 'Activity log saved' });
  } catch (err) {
    logError('❌ Failed to save activity log', err);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

// ------------------------------
// ✅ POST /api/logs
// Receives frontend logs and stores them
// Body: { level, message, meta? }
// ------------------------------
router.post('/', async (req, res) => {
  try {
    const { level = 'info', message, meta = {} } = req.body;

    if (!message) {
      return res.status(400).json({ success: false, error: 'Missing log message' });
    }

    const timestamp = new Date().toISOString();
    const entry = { timestamp, level, message, meta };

    // Print to backend console
    const label = level.toUpperCase();
    const printer = {
      DEBUG: console.debug,
      INFO: console.log,
      WARN: console.warn,
      ERROR: console.error,
    }[label] || console.log;

    printer(`[${label}]`, message, meta);

    // Append to file
    const logDir = path.resolve(__dirname, '../../logs');
    const logFile = path.join(logDir, 'frontend.log');

    if (!fs.existsSync(logDir)) {
      fs.mkdirSync(logDir, { recursive: true });
    }

    fs.appendFileSync(logFile, JSON.stringify(entry) + '\n', 'utf-8');

    logInfo('📨 Frontend log recorded', { level, message });
    res.status(204).end();
  } catch (err) {
    logError('❌ Failed to handle frontend log', err);
    res.status(500).json({ success: false, error: 'Internal log handler error' });
  }
});

export default router;
