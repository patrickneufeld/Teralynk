// ✅ FILE: /backend/src/routes/index.mjs

import express from 'express';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

console.log('🔄 Starting route imports...');

const routes = [
    { name: 'auth', path: '/api/auth', module: './authRoutes.mjs' },
    { name: 'user', path: '/api/users', module: './userRoutes.mjs' },
    { name: 'ai', path: '/api/ai', module: './aiRoutes.mjs' },
    { name: 'admin', path: '/api/admin', module: './adminRoutes.mjs' },
    { name: 'storage', path: '/api/storage', module: './storageRoutes.mjs' },
    { name: 's3', path: '/api/s3', module: './s3Routes.mjs' },
    { name: 'file', path: '/api/files', module: './fileRoutes.mjs' },
    { name: 'fileShare', path: '/api/shares', module: './fileShareRoutes.mjs' },
    { name: 'marketplace', path: '/api/marketplace', module: './marketplaceRoutes.mjs' },
    { name: 'notification', path: '/api/notifications', module: './notificationRoutes.mjs' },
    { name: 'performance', path: '/api/performance', module: './performanceRoutes.mjs' },
    { name: 'workflow', path: '/api/workflows', module: './workflowRoutes.mjs' },
    { name: 'troubleshooting', path: '/api/troubleshoot', module: './troubleshootingRoutes.mjs' },
    { name: 'feedback', path: '/api/feedback', module: './feedbackRoutes.mjs' },
    { name: 'developer', path: '/api/developers', module: './developerRoutes.mjs' },
    { name: 'billing', path: '/api/billing', module: './billingRoutes.mjs' },
    { name: 'app', path: '/api/apps', module: './appRoutes.mjs' },
    { name: 'key', path: '/api/keys', module: './keyRoutes.mjs' },
    { name: 'aiPrompt', path: '/api/ai/prompts', module: './aiPromptTemplateRoutes.mjs' },
    { name: 'secrets', path: '/api/secrets', module: './secrets.mjs' }
];

/**
 * Mount all application routes
 * @param {express.Application} app - Express application instance
 * @returns {Promise<boolean>}
 */
async function mountAllRoutes(app) {
    console.log('\n🛣️ Starting route mounting process...');

    const mountedRoutes = [];
    const failedRoutes = [];

    for (const route of routes) {
        try {
            console.log(`\n📝 Processing route: ${route.name}`);
            console.log(`   Path: ${route.path}`);
            console.log(`   Module: ${route.module}`);

            const absoluteModulePath = pathToFileURL(path.resolve(__dirname, route.module)).href;
            console.log(`   ⏳ Importing module at: ${absoluteModulePath}`);
            const routeModule = await import(absoluteModulePath);

            if (!routeModule.default || typeof routeModule.default !== 'function') {
                const errorMsg = !routeModule.default
                    ? 'No default export found'
                    : 'Export is not a function';
                console.error(`   ❌ ${errorMsg} in ${route.module}`);
                failedRoutes.push({ ...route, error: errorMsg });
                continue;
            }

            console.log(`   🔄 Mounting route...`);
            app.use(route.path, routeModule.default);

            console.log(`   ✅ Successfully mounted ${route.name} route`);
            mountedRoutes.push(route.path);

        } catch (error) {
            console.error(`   ❌ Failed to mount ${route.name} route:`, error);
            failedRoutes.push({ ...route, error: error.message });
        }
    }

    console.log('\n💉 Adding health check endpoint...');
    app.get('/health', (req, res) => {
        res.json({
            status: 'healthy',
            timestamp: new Date().toISOString(),
            mountedRoutes,
            failedRoutes: failedRoutes.map(r => ({
                name: r.name,
                path: r.path,
                error: r.error
            }))
        });
    });

    console.log('🔍 Adding 404 handler...');
    app.use('*', (req, res) => {
        res.status(404).json({
            error: 'Not Found',
            path: req.originalUrl,
            availableRoutes: mountedRoutes
        });
    });

    console.log('\n📊 Route mounting complete:');
    console.log(`   ✅ Successfully mounted: ${mountedRoutes.length} routes`);
    console.log(`   ❌ Failed to mount: ${failedRoutes.length} routes`);

    if (failedRoutes.length > 0) {
        console.log('\n⚠️ Failed routes:');
        failedRoutes.forEach(route => console.log(`   - ${route.name}: ${route.error}`));
    }

    return true;
}

export default mountAllRoutes;
