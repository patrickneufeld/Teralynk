import winston from "winston";
import { v4 as uuidv4 } from "uuid";
import { logToDatabase } from "./dbLogger.mjs";

// === Constants ===
const MAX_STACK_SIZE = 10;
const loggingStack = new Set();

// === Fallback-safe formatter ===
const customFormat = winston.format.printf(({ level, message, timestamp, ...meta }) => {
    try {
        return JSON.stringify({
            timestamp,
            level: level.toUpperCase(),
            message: typeof message === "string" ? message : JSON.stringify(message),
            ...meta,
        });
    } catch (error) {
        return JSON.stringify({
            timestamp,
            level: level.toUpperCase(),
            message: "Error formatting log message",
            error: error.message,
        });
    }
});

// === Winston Logger Instance (used for default export) ===
const coreLogger = winston.createLogger({
    level: process.env.LOG_LEVEL || "info",
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.metadata({ fillExcept: ["message", "level", "timestamp"] }),
        customFormat
    ),
    transports: [
        new winston.transports.Console({
            format: winston.format.combine(
                winston.format.colorize(),
                winston.format.simple()
            ),
            handleExceptions: true
        }),
        new winston.transports.File({
            filename: "logs/error.log",
            level: "error",
            handleExceptions: true
        }),
        new winston.transports.File({
            filename: "logs/combined.log",
            handleExceptions: true
        })
    ],
    exitOnError: false
});

// === Logging Utilities ===
const executeSafeLog = async (operation, logFunc) => {
    const logId = uuidv4();
    if (loggingStack.size >= MAX_STACK_SIZE) {
        console.warn(`[WARN] Logging stack overflow (${operation}). Skipped.`);
        return logId;
    }
    try {
        loggingStack.add(logId);
        await logFunc();
    } catch (err) {
        console.error(`[ERROR] Failed log operation (${operation}): ${err.message}`);
    } finally {
        loggingStack.delete(logId);
    }
    return logId;
};

const logToDbSafely = async (collection, data) => {
    if (loggingStack.size >= MAX_STACK_SIZE) return;
    try {
        await logToDatabase(collection, data);
    } catch (err) {
        console.error(`[ERROR] Database logging failed for "${collection}": ${err.message}`);
    }
};

// === Main Log Methods ===
export const logError = async (error, context = "Error", meta = {}) => {
    const requestId = meta.requestId || uuidv4();
    const errorMessage = error?.message || String(error);

    return executeSafeLog("error", async () => {
        coreLogger.error(errorMessage, {
            context,
            stack: error?.stack,
            requestId,
            ...meta
        });

        await logToDbSafely("error_logs", {
            error_type: context,
            message: errorMessage,
            stack_trace: error?.stack,
            metadata: meta,
            requestId
        });
    });
};

export const logInfo = async (message, context = "Info", meta = {}) => {
    const requestId = meta.requestId || uuidv4();

    return executeSafeLog("info", async () => {
        coreLogger.info(message, {
            context,
            requestId,
            ...meta
        });

        await logToDbSafely("backend_logs", {
            event_type: "INFO",
            details: { message, context, ...meta },
            requestId
        });
    });
};

export const logActivity = async (userId, action, details = {}) => {
    const requestId = uuidv4();

    return executeSafeLog("activity", async () => {
        coreLogger.info(`User Activity: ${action}`, {
            userId,
            action,
            details,
            requestId
        });

        await logToDbSafely("activity_logs", {
            user_id: userId,
            action_type: action,
            details,
            requestId
        });
    });
};

export const logRequest = (req, res, next) => {
    const requestId = uuidv4();
    const startTime = Date.now();

    res.on("finish", () => {
        executeSafeLog("request", async () => {
            const duration = Date.now() - startTime;
            coreLogger.info(`HTTP Request: ${req.method} ${req.url}`, {
                statusCode: res.statusCode,
                duration,
                requestId
            });

            await logToDbSafely("backend_logs", {
                event_type: "HTTP_REQUEST",
                details: {
                    method: req.method,
                    url: req.url,
                    status: res.statusCode,
                    duration,
                    userAgent: req.get("user-agent"),
                    ip: req.ip
                },
                requestId
            });
        });
    });

    next();
};

export const logDebug = async (message, context = "Debug", meta = {}) => {
    const requestId = meta.requestId || uuidv4();
    return executeSafeLog("debug", async () => {
        coreLogger.debug(message, {
            context,
            requestId,
            ...meta
        });
    });
};

// === Full Export ===
export default {
    logError,
    logInfo,
    logActivity,
    logRequest,
    logDebug,
    error: (...args) => logError(...args),
    info: (...args) => logInfo(...args),
    debug: (...args) => logDebug(...args),
    generateRequestId: uuidv4
};