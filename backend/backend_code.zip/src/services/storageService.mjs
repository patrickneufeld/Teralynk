// /Users/patrick/Projects/Teralynk/backend/src/services/storageService.js

import { S3Client, HeadObjectCommand, ListObjectsV2Command } from "@aws-sdk/client-s3";
import { logInfo, logError } from "../utils/bootstrapLogger.mjs";

const s3 = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

/**
 * List all files for a specific user in their S3 prefix.
 * @param {string} userId
 * @returns {Promise<Array>} List of files
 */
export async function listUserFiles(userId) {
  try {
    const prefix = `users/${userId}/`;
    const command = new ListObjectsV2Command({
      Bucket: process.env.S3_BUCKET_NAME,
      Prefix: prefix,
    });

    const data = await s3.send(command);
    const files = data.Contents || [];

    return files.map((file) => ({
      key: file.Key,
      size: file.Size,
      lastModified: file.LastModified,
    }));
  } catch (error) {
    logError("storageService:listUserFiles", error);
    throw new Error("Failed to list user files.");
  }
}

/**
 * Get the total storage usage in bytes for a specific user.
 * @param {string} userId
 * @returns {Promise<number>} Total bytes used
 */
export async function getUserTotalStorage(userId) {
  try {
    const files = await listUserFiles(userId);
    const totalBytes = files.reduce((acc, file) => acc + file.size, 0);
    logInfo("storageService:getUserTotalStorage", { userId, totalBytes });
    return totalBytes;
  } catch (error) {
    logError("storageService:getUserTotalStorage", error);
    throw new Error("Failed to calculate total user storage.");
  }
}
