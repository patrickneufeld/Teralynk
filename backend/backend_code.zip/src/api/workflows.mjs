// ✅ FILE: /backend/src/api/workflows.js

import express from 'express';
import { requireAuth } from '../middleware/authMiddleware.mjs';
import { logInfo } from '../utils/logging/index.mjs';

const router = express.Router();

/**
 * @route GET /api/workflows
 * @desc Basic workflow API - placeholder
 */
router.get('/', requireAuth, (req, res) => {
    const userId = req.user?.id; // Safely access userId in case req.user is null/undefined

    logInfo('Workflow base route hit', { userId: userId });

    res.json({
        success: true,
        message: 'Workflow API is operational.',
        userId: userId
    });
});

// (You can add real workflow routes here later)

export default router;
