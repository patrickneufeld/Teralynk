// FILE: backend/src/api/sampleRoute.js

import express from "express";
import { body } from "express-validator";
import validateRequest from "../middleware/inputValidationMiddleware.mjs";
import csrfProtection from "../middleware/csrfMiddleware.mjs";

const router = express.Router();

/**
 * ✅ Sample POST route with input validation + CSRF protection
 */
router.post(
  "/create",
  csrfProtection,
  validateRequest([
    body("name").isString().withMessage("Name must be a string").notEmpty().withMessage("Name is required"),
    body("email").isEmail().withMessage("Invalid email format"),
  ]),
  (req, res) => {
    const { name, email } = req.body;
    res.status(201).json({
      message: "✅ Resource created successfully",
      data: { name, email },
    });
  }
);

export default router;
